package com.projectMoldSystems.immobileProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImmobileProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImmobileProjectApplication.class, args);
	}

}
