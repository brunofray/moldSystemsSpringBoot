package com.projectMoldSystems.immobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImmobileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImmobileApplication.class, args);
	}

}
