package br.com.moldsystems.projetoFray;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoFrayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoFrayApplication.class, args);
	}

}
